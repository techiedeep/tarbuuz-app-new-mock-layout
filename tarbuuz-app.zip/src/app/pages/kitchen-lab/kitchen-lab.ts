import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Header } from '../../components/header/header';
import { Footer } from '../../components/footer/footer';
import { KitchenLabService } from '../../shared/services/kitchen-lab.service';
import { KitchenChoice } from '../../shared/models/kitchen-lab/kitchen-lab.model';

/**
 * Kitchen Lab — converted from a standalone HTML/vanilla-JS reference.
 * The lifecycle/criteria/royalty/stats/FAQ sections are static content
 * rendering (straightforward signal-free @for loops). The interactive
 * demo (kitchen choice → record → submit) is where the real conversion
 * work is: the original's setInterval-based recording timer had no
 * lifecycle to worry about since the whole page unloads together, but as
 * an Angular component this page can be routed away from mid-recording —
 * without explicit cleanup, that interval would keep ticking forever in
 * the background. Cleared via DestroyRef.onDestroy() specifically to
 * cover that case, not just the "user clicks stop" case the original
 * only needed to handle.
 */
@Component({
  selector: 'app-kitchen-lab',
  standalone: true,
  imports: [Header, Footer, ReactiveFormsModule, RouterLink],
  templateUrl: './kitchen-lab.html',
  styleUrl: './kitchen-lab.scss',
})
export class KitchenLab {
  private readonly kitchenLabService = inject(KitchenLabService);
  private readonly destroyRef = inject(DestroyRef);

  readonly lifecycleStages = this.kitchenLabService.lifecycleStages;
  readonly matchCriteria = this.kitchenLabService.matchCriteria;
  readonly royaltySteps = this.kitchenLabService.royaltySteps;
  readonly stats = this.kitchenLabService.stats;
  readonly faqItems = this.kitchenLabService.faqItems;

  // ── Interactive demo state ──
  readonly kitchenChoice = signal<KitchenChoice | null>(null);
  readonly isRecording = signal(false);
  readonly recordingSeconds = signal(0);
  readonly submitted = signal(false);

  readonly recipeNameControl = new FormControl('', { nonNullable: true });
  private readonly recipeName = signal('');

  private intervalId: ReturnType<typeof setInterval> | null = null;

  readonly formattedTime = computed(() => this.kitchenLabService.formatRecordingTime(this.recordingSeconds()));
  readonly recordingStatus = computed(() => {
    if (this.isRecording()) return 'Recording…';
    return this.recordingSeconds() > 0 ? 'Paused' : 'Not started';
  });
  readonly recordButtonLabel = computed(() => {
    if (this.isRecording()) return 'Stop Recording';
    return this.recordingSeconds() > 0 ? 'Resume Recording' : 'Start Recording';
  });

  readonly canSubmit = computed(
    () => this.kitchenChoice() !== null && this.recordingSeconds() > 0 && this.recipeName().trim().length > 0,
  );

  readonly demoHint = computed(() => {
    if (this.kitchenChoice() === null) return 'Choose a kitchen above to continue';
    if (this.recordingSeconds() === 0) return 'Start recording at least a few seconds to continue';
    if (this.recipeName().trim().length === 0) return 'Give your recipe a name to continue';
    return "You're ready — submit whenever you like";
  });

  readonly successTitle = computed(() => `"${this.recipeName()}" is submitted`);

  // ── FAQ accordion — single item open at a time, matching the original ──
  readonly openFaqIndex = signal<number | null>(null);

  constructor() {
    this.recipeNameControl.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((value) => this.recipeName.set(value));

    // The one real lifecycle concern this conversion has that the
    // original static page never did: if the user navigates away while
    // recording, this interval must not keep running in the background.
    this.destroyRef.onDestroy(() => this.clearRecordingInterval());
  }

  selectKitchen(choice: KitchenChoice): void {
    this.kitchenChoice.set(choice);
  }

  toggleRecording(): void {
    if (this.isRecording()) {
      this.isRecording.set(false);
      this.clearRecordingInterval();
      return;
    }
    this.isRecording.set(true);
    this.intervalId = setInterval(() => this.recordingSeconds.update((s) => s + 1), 1000);
  }

  private clearRecordingInterval(): void {
    if (this.intervalId !== null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  submitRecipe(): void {
    if (!this.canSubmit()) return;
    if (this.isRecording()) {
      this.isRecording.set(false);
      this.clearRecordingInterval();
    }
    this.submitted.set(true);
  }

  resetDemo(): void {
    this.kitchenChoice.set(null);
    this.isRecording.set(false);
    this.recordingSeconds.set(0);
    this.clearRecordingInterval();
    this.recipeNameControl.setValue('');
    this.submitted.set(false);
  }

  toggleFaq(index: number): void {
    this.openFaqIndex.update((current) => (current === index ? null : index));
  }
}
