import { Component, ElementRef, HostListener, computed, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, Router, NavigationStart } from '@angular/router';
import { NavLink } from '../../shared/models/home/home.models';
import { ROUTE_PATHS } from '../../shared/routes.constants';
import { UserMenu } from '../user-menu/user-menu';
import { AuthApi } from '../../shared/services/auth-api';

@Component({
  selector: 'app-header',
  imports: [RouterLink, RouterLinkActive, UserMenu],
  templateUrl: './header.html',
  styleUrl: './header.scss',
})
export class Header {
  private readonly elementRef = inject(ElementRef);
  private readonly router = inject(Router);
  private readonly authApi = inject(AuthApi);

  private readonly allNavLinks: readonly NavLink[] = [
    { label: 'Home', path: ROUTE_PATHS.home },
    { label: 'Our Story', path: ROUTE_PATHS.ourStory },
    { label: 'Events', path: ROUTE_PATHS.events },
    { label: 'Buuz', path: ROUTE_PATHS.buuz },
    { label: 'Kitchen Lab', path: ROUTE_PATHS.kitchenLab },
    { label: 'Pricing', path: ROUTE_PATHS.pricing },
  ];

  // "Events" links to the Foodie events dashboard specifically - showing
  // it to a signed-in Host or Supplier who hasn't also enabled a Foodie
  // profile would send them to a page that isn't theirs, so it's gated
  // behind the Foodie role once someone is actually signed in. A
  // signed-out visitor hasn't chosen a role yet at all, so the link
  // stays visible by default rather than being hidden before there's
  // even a session to check roles against - filtered here rather than
  // left for FoodieEventsService's own route guard to catch, since a
  // nav link that's visible but redirects away on click reads as
  // broken, not as "not for you." A signed-in user with multiple roles
  // (Foodie + Host, via the profile switcher) still sees it, since the
  // roles array check doesn't require Foodie to be their *only* role.
  readonly navLinks = computed<readonly NavLink[]>(() => {
    const session = this.authApi.currentSession();
    if (!session || session.roles.includes('foodie')) return this.allNavLinks;
    return this.allNavLinks.filter((link) => link.path !== ROUTE_PATHS.events);
  });

  // Every nav link needs this, not just Events - the header is sticky
  // across every page, and this router has no scrollPositionRestoration
  // configured. Left as a plain [routerLink] rather than swapped for a
  // manual (click) navigation so routerLinkActive keeps working - this
  // just rides along after Angular's own navigation, closing the mobile
  // menu and resetting scroll once the new page has actually loaded.
  onNavLinkClick(): void {
    this.mobileMenuOpen.set(false);
    setTimeout(() => window.scrollTo(0, 0), 0);
  }

  // Below 860px the horizontal nav-links previously just had
  // `display:none` with no replacement at all — a real dead end for
  // anyone on a tablet or small laptop, not merely an aesthetic gap.
  // This toggle drives the hamburger-triggered mobile panel that replaces
  // that inline list at the same breakpoint (see header.scss).
  readonly mobileMenuOpen = signal(false);

  constructor(router: Router) {
    // Route changes are the one case a raw document-click listener can't
    // catch — clicking a nav link inside the open panel navigates via
    // Angular's router, not a DOM click bubbling to document, so without
    // this the panel would stay open behind the newly-loaded page.
    router.events.subscribe((event) => {
      if (event instanceof NavigationStart) this.mobileMenuOpen.set(false);
    });
  }

  toggleMobileMenu(): void {
    this.mobileMenuOpen.update((open) => !open);
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.mobileMenuOpen()) return;
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.mobileMenuOpen.set(false);
    }
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.mobileMenuOpen.set(false);
  }
}
