export interface CartItem {
  readonly drinkId: number;
  readonly drinkName: string;
  quantity: number;
}

export interface AddToCartPayload {
  readonly drinkId: number;
  readonly drinkName: string;
  readonly quantity: number;
}
