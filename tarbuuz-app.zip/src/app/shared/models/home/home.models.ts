/**
 * Data models for the Tarbuuz home page.
 *
 * Every repeated content block on the page (AI capability cards, product
 * sections, FAQ items, etc.) is modeled here as a typed interface and
 * populated as readonly data in `home.ts`. This is a deliberate structural
 * choice over hardcoding six near-identical `<div class="ai-card">` blocks
 * directly in the template: it gives compile-time type safety on every
 * field, a single place to add/edit/reorder content, and a template that
 * stays a thin, readable rendering layer instead of 400 lines of repeated
 * markup.
 */

export interface NavLink {
  readonly label: string;
  readonly path: string;
}

export interface HeroCapability {
  readonly icon: string;
  readonly name: string;
  readonly status: string;
}

export interface AiCapabilityCard {
  readonly icon: string;
  readonly title: string;
  readonly description: string;
}

export interface TabDemo {
  readonly icon: string;
  readonly label: string;
  readonly emoji: string;
  readonly title: string;
  readonly description: string;
  readonly features: readonly string[];
}

export interface FlowStep {
  readonly number: string;
  readonly title: string;
  readonly description: string;
}

export type ProductTagVariant = 'ai' | 'plain';

export interface ProductOffering {
  readonly visualClass: string;
  readonly icon: string;
  readonly showHalo: boolean;
  readonly tagVariant: ProductTagVariant;
  readonly tagLabel: string;
  readonly name: string;
  readonly description: string;
  readonly features: readonly string[];
  readonly ctaLabel: string;
  readonly ctaPath: string;
}

export type StatVariant = 'default' | 'amber' | 'indigo';

export interface StatItem {
  readonly value: string;
  readonly label: string;
  readonly variant: StatVariant;
}

export interface Testimonial {
  readonly quote: string;
  readonly authorInitials: string;
  readonly authorName: string;
  readonly authorRole: string;
}

export interface FaqItem {
  readonly question: string;
  readonly answer: string;
}

export interface FooterLinkColumn {
  readonly heading: string;
  readonly links: readonly NavLink[];
}

// ────────────────────────────────────────────────────────────────────────
// Real backend/content DTOs (from the uploaded home.interface.ts) — added
// for completeness, not force-integrated above.
//
// NavLink collides by name but not by shape: this file's own NavLink
// (label + path) is built for Angular's routerLink and is actively used
// by Header, Footer, and Home today. The real NavLink is (label + href) —
// a plain-anchor shape for external/non-routed links. These are genuinely
// different concepts wearing the same name, not a naming inconsistency to
// resolve in favor of one; kept both, real one renamed to avoid the
// collision. Same reasoning for Testimonial/Stat below — the real
// versions carry different fields (content vs quote, authorLocation,
// rating) for what's presumably a CMS-driven testimonials feed, distinct
// from this page's own simpler hardcoded testimonial data.
// ────────────────────────────────────────────────────────────────────────

export interface ExternalNavLink {
  readonly label: string;
  readonly href: string;
}

export interface HomeFeature {
  readonly icon: string;
  readonly title: string;
  readonly description: string;
  readonly link: string;
}

export interface HomeStep {
  readonly number: number;
  readonly icon: string;
  readonly title: string;
  readonly description: string;
}

export interface HomeUserType {
  readonly icon: string;
  readonly title: string;
  readonly description: string;
  readonly features: readonly string[];
  readonly buttonText: string;
}

/** The real, richer testimonial DTO — distinct from this page's own
 *  working Testimonial above; see file-level note. */
export interface HomeTestimonialDTO {
  readonly content: string;
  readonly authorName: string;
  readonly authorAvatar: string;
  readonly authorRole: string;
  readonly authorLocation: string;
  readonly rating: number;
}

export interface HomeStatDTO {
  readonly number: string;
  readonly label: string;
}

export interface SocialLink {
  readonly icon: string;
  readonly href: string;
}

export interface HomeFooterSection {
  readonly title: string;
  readonly links: ReadonlyArray<{ label: string; href: string }>;
}
